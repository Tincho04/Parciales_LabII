﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Astro
    {
        #region atributos
        int duracionOrbita;
        int duracionRotacion;
        protected string nombre;
        #endregion

        #region metodos
        /// <summary>
        /// Constructor de la clase Astro
        /// <param name="duracionOrbita"></param>
        /// <param name="duracionRotacion"></param>
        /// <param name="nombre"></param>
        /// </summary>
        /// <returns></returns>
        public Astro(int duracionOrbita, int duracionRotacion, string nombre)
        {
        }

        /// <summary>
        /// muestra todos los atributos de la clase Astro
        /// </summary>
        /// <returns></returns>
        protected string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Nombre:    {0}\r\n", this.nombre);
            sb.AppendFormat("Orbita:    {0}\r\n", this.duracionOrbita.ToString());
            sb.AppendFormat("Rotacion:  {0}\r\n", this.duracionRotacion.ToString());
            sb.AppendLine("---------------------");

            return sb.ToString();
        }

        /// <summary>
        /// firma del metodo abstracto de la orbita
        /// </summary>
        /// <returns></returns>
        public abstract string Orbitar();

        /// <summary>
        /// Informa el el periodo de rotacion
        /// </summary>
        /// <returns></returns>
        public virtual string Rotar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Rotando. Tiempo estimado:  {0}\r\n", this.duracionRotacion.ToString());

            return sb.ToString();

        }
        #endregion


    }
}
