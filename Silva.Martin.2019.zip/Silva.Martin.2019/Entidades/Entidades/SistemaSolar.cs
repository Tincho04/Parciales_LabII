﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class SistemaSolar
    {
        #region atributo
        private List<Astro> planetas;
        #endregion

        #region propiedad
        public List<Astro> Planetas
        {
            get{return this.planetas; }
        }
        #endregion

        #region metodo
        string mostrarInformacionAstros()
            {           

            }
        #endregion
    }
}
