﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Planeta : Astro
    {
        #region atributos
        private int cantSatelites;
        private Tipo tipo;
        private List<Astro> satelites;
        #endregion

        #region propiedades
        public List<Astro> Satelites
        {
            get{return this.satelites;}
        }
        #endregion

        #region metodos
        /// <summary>
        /// Constructor con los atributos de Astro mas los de planeta
        /// </summary>
        /// <param name="duracionOrbita"></param>
        /// <param name="duracionRotacion"></param>
        /// <param name="nombre"></param>
        /// <param name="cantSatelites"></param>
        /// <param name="tipo"></param>
        /// <returns></returns>
        public Planeta(int duracionOrbita, int duracionRotacion, string nombre, int cantSatelites, Tipo tipo) : this(duracionOrbita, duracionRotacion, nombre)
        {
            this.tipo = tipo;
            this.cantSatelites = cantSatelites;
        }

        /// <summary>
        /// Constructor con los atributos de Astro 
        /// </summary>
        /// <param name="duracionOrbita"></param>
        /// <param name="duracionRotacion"></param>
        /// <param name="nombre"></param>
        /// <returns></returns>
        public Planeta(int duracionOrbita, int duracionRotacion, string nombre) : base(duracionOrbita, duracionRotacion, nombre)
        {
        }

        /// <summary>
        /// Dos planetas son iguales si comparten el mismo nombre
        /// </summary>
        /// <param name="planeta1"></param>
        /// <param name="planeta2"></param>
        /// <returns></returns>
        public static bool operator ==(Planeta planeta1, Planeta planeta2)
        {
            return (planeta1.nombre == planeta2.nombre);
        }
        /// <summary>
        /// Dos planetas son distintos si su nombre es distinto
        /// </summary>
        /// <param name="planeta1"></param>
        /// <param name="planeta2"></param>
        /// <returns></returns>
        public static bool operator !=(Planeta planeta1, Planeta planeta2)
        {
            return !(planeta1.nombre == planeta2.nombre);
        }

        /// <summary>
        /// Identifica si el planeta posee el satelite ingresado
        /// </summary>
        /// <param name="planeta"></param>
        /// <param name="satelite"></param>
        /// <returns></returns>
        public static bool operator ==(Planeta planeta, Satelite satelite)
        {
            return (planeta.satelites.ToString() == satelite.Nombre);
        }
        /// <summary>
        /// En caso de que el satelite no se encuentre para el planeta
        /// </summary>
        /// <param name="planeta"></param>
        /// <param name="satelite"></param>
        /// <returns></returns>
        public static bool operator !=(Planeta planeta, Satelite satelite)
        {
            return !(planeta.satelites.ToString() == satelite.Nombre);
        }

        /// <summary>
        /// verifica si el astro es un planeta, caso de no serlo lo añade como satelite
        /// </summary>
        /// <param name="astro"></param>
        /// <param name="planeta"></param>
        /// <returns></returns>
        public static bool operator +(Astro astro, Planeta planeta)
        {
            bool retorno = false;

            if ((astro.GetType() != planeta.GetType()))
            {
                Astro.Add(astro);
                return retorno;
            }

            return retorno;

        }

        /// <summary>
        /// Sobrecarga del metodo Orbitar
        /// </summary>
        /// <returns></returns>
        public override string Orbitar()
        {        
        StringBuilder sb = new StringBuilder();

        sb.AppendFormat("Orbita el planeta:  {0}\r\n", this.nombre);

        return sb.ToString();
        }

        /// <summary>
        /// Sobrecarga del metodo Rotar
        /// </summary>
        /// <returns></returns>
        public override string Rotar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Rota el planeta:  {0}\r\n", this.nombre);

            return sb.ToString();
        }

        /// <summary>
        /// Sobrecarga del metodo Mostrar
        /// </summary>
        /// <returns></returns>
        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(base.Mostrar());
            sb.AppendLine("Planeta");
            sb.AppendFormat("Cantidad de satelites:   {0}\r\n", this.cantSatelites.ToString());
            sb.AppendFormat("Tipo de planeta:   {0}\r\n", this.tipo.ToString());
            sb.AppendLine("---------------------");

            return sb.ToString();
        }
        #endregion
    }
}
