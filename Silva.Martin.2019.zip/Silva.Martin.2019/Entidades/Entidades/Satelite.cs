﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Satelite : Astro

    {
        #region propiedades
        public string Nombre
        {
            get { return nombre; }
        }
        #endregion

        #region metodos
        /// <summary>
        /// Sobrecarga del metodo Orbitar
        /// </summary>
        /// <returns></returns>
        public override string Orbitar()
        {        
        StringBuilder sb = new StringBuilder();

        sb.AppendFormat("Orbita el satelite:  {0}\r\n", this.nombre);

        return sb.ToString();
        }

        /// <summary>
        /// Constructor con los atributos de Astro mas el de satelite
        /// </summary>
        /// <param name="duracionOrbita"></param>
        /// <param name="duracionRotacion"></param>
        /// <param name="nombre"></param>
        /// <param name="nombre"></param>
        /// <returns></returns>
        public Satelite(int duracionOrbita, int duracionRotacion, string nombre) : base(duracionOrbita, duracionRotacion, nombre)
    {
    }

        /// <summary>
        /// Sobrecarga del metodo Mostrar
        /// </summary>
        /// <returns></returns>

        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(base.Mostrar());
            sb.AppendLine("Satelite");
            sb.AppendFormat("Nombre:   {0}\r\n", this.nombre);
            sb.AppendLine("---------------------");

            return sb.ToString();
        }
        #endregion
    }
}
