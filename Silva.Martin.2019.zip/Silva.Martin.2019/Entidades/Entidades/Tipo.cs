using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  #region Enumerado
  public enum Tipo
    {
        Rocoso, Gaseoso
    }
  #endregion
}
